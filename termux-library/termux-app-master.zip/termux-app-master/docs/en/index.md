---
page_ref: /docs/apps/termux/index.html
---

# Termux App Docs

<!--- DOC_HEADER_PLACEHOLDER -->

Welcome to documentation for the [Termux App].

##

[Termux App]: https://github.com/termux/termux-app
