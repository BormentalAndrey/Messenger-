package com.mystery_of_orient_express.match3_engine.model;

public interface IAnimation
{
	public void update(float delta);
}