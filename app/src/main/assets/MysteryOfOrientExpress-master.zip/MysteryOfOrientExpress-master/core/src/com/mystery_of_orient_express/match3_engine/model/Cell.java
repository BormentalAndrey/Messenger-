package com.mystery_of_orient_express.match3_engine.model;

public class Cell
{
	public CellObject object = null;
	public int effect = -1;
}
