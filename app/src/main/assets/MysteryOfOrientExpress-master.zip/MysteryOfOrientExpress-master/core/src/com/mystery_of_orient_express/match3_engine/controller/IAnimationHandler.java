package com.mystery_of_orient_express.match3_engine.controller;

import com.mystery_of_orient_express.match3_engine.model.IAnimation;

public interface IAnimationHandler
{
	public void onComplete(IAnimation animation);
}