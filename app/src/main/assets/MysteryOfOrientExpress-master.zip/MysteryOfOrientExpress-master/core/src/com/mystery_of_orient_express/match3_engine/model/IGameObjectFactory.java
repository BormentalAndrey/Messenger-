package com.mystery_of_orient_express.match3_engine.model;

public interface IGameObjectFactory
{
	public GameObject newGem(int i, int j);
}
