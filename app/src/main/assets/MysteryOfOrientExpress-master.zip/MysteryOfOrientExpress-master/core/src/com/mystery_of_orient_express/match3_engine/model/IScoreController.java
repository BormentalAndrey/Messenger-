package com.mystery_of_orient_express.match3_engine.model;

public interface IScoreController
{
	public void updateCombo(int matches);
	public void updateScore(int score);
}
