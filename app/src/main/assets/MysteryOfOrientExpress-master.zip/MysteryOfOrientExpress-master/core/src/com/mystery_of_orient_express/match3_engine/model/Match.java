package com.mystery_of_orient_express.match3_engine.model;

public class Match
{
	int kind;
	int i;
	int j;
	int length;

	public Match()
	{
		this.kind = -1;
		this.length = 0;
		this.i = 0;
		this.j = 0;
	}
}
