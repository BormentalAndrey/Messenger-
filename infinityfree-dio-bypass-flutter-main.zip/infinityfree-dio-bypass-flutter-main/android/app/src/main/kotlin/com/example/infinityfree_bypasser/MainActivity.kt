package com.example.infinityfree_bypasser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
